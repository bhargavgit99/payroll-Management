﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace PayRoll
{
    public partial class DashBoard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Unnamed2_Click(object sender, EventArgs e)
        {
            String name = emp.SelectedItem.Text;
            String role=emp.SelectedValue;
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=|DataDirectory|\\PayRoll.mdf;Integrated Security=True");
            con.Open();
            SqlCommand cmd=new SqlCommand("SELECT * FROM Salary WHERE role='"+ role +"'",con);
            SqlDataReader result=cmd.ExecuteReader();
            result.Read();
            double basic = double.Parse(result["Basic_Pay"].ToString());
            double Dns = double.Parse(result["DNS_Allows"].ToString());
            double House_Rent = double.Parse(result["House_Rent"].ToString());
            double Other_Allowance = double.Parse(result["Other_Allowance"].ToString());

            double Dn_c = basic * 0.12;
            double hr_c = basic * (House_Rent/ 100);
            double ot_c = basic * (Other_Allowance / 100);

            Session["basic"] = basic;
            Session["Dns"] = Dn_c;
            Session["House_Rent"] = hr_c;
            Session["Other_Allowance"] = ot_c;

            Session["name"] = name;
            Session["role"] = role;
            Response.Redirect("PayRoll.aspx");

     }
    }
}