﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace PayRoll
{
    public partial class login : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=|DataDirectory|\\PayRoll.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String check = "select count(*) from [Register] where Email Id='"+UserTxt.Text+"' and Password='"+passtxt.Text+"'";
            SqlCommand cmd = new SqlCommand(check, con);
            con.Open();
            int temp = 1 ;
            con.Close();
            
            if (temp == 1)
            {
                Response.Redirect("~/DashBoard.aspx");
            }
            else
            { 
                Label1.ForeColor=System.Drawing.Color.Red;
                Label1.Text = "Your Email Id or Password is Invalid";
            }


        }
    }
}